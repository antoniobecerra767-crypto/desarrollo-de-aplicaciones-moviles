package com.example.myapplication.views

import android.Manifest
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Person
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.example.myapplication.viewmodel.AuthViewModel

@Composable
fun RegisterScreen(navController: NavController, viewModel: AuthViewModel) {
    val context = LocalContext.current

    val cameraLauncher = rememberLauncherForActivityResult(ActivityResultContracts.TakePicturePreview()) { bitmap ->
        if (bitmap != null) Toast.makeText(context, "Foto del local capturada", Toast.LENGTH_SHORT).show()
    }

    val locationLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { isGranted ->
        if (isGranted) Toast.makeText(context, "Ubicación del negocio obtenida", Toast.LENGTH_SHORT).show()
        else Toast.makeText(context, "Permiso GPS denegado", Toast.LENGTH_SHORT).show()
    }

    Column(
        modifier = Modifier.fillMaxSize().padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text("Registro Emprendedor Gastronómico", style = MaterialTheme.typography.titleLarge)
        Spacer(modifier = Modifier.height(24.dp))

        OutlinedTextField(
            value = viewModel.nombre.value,
            onValueChange = { viewModel.onNombreChange(it) },
            label = { Text("Nombre del Local") },
            leadingIcon = { Icon(Icons.Default.Person, contentDescription = "Ícono de usuario") },
            isError = viewModel.nombreError.value != null,
            modifier = Modifier.fillMaxWidth()
        )
        AnimatedVisibility(
            visible = viewModel.nombreError.value != null,
            enter = fadeIn(), exit = fadeOut()
        ) {
            Text(text = viewModel.nombreError.value ?: "", color = MaterialTheme.colorScheme.error)
        }

        Spacer(modifier = Modifier.height(16.dp))

        OutlinedTextField(
            value = viewModel.rut.value,
            onValueChange = { viewModel.onRutChange(it) },
            label = { Text("RUT Empresa (Ej: 76.123.456-7)") },
            leadingIcon = { Icon(Icons.Default.Info, contentDescription = "Ícono RUT") },
            isError = viewModel.rutError.value != null,
            modifier = Modifier.fillMaxWidth()
        )
        AnimatedVisibility(
            visible = viewModel.rutError.value != null,
            enter = fadeIn(), exit = fadeOut()
        ) {
            Text(text = viewModel.rutError.value ?: "", color = MaterialTheme.colorScheme.error)
        }

        Spacer(modifier = Modifier.height(24.dp))

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = { cameraLauncher.launch(null) }) {
                Text("Cámara (Foto Local)")
            }
            Button(onClick = { locationLauncher.launch(Manifest.permission.ACCESS_FINE_LOCATION) }) {
                Icon(Icons.Default.LocationOn, contentDescription = "GPS")
                Spacer(Modifier.width(4.dp))
                Text("GPS")
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        Button(
            onClick = {
                if (viewModel.validarFormularioCompleto()) {
                    viewModel.guardarClienteLocal(context)
                    navController.navigate("home/${viewModel.nombre.value}")
                }
            },
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("Finalizar Registro")
        }
    }
}