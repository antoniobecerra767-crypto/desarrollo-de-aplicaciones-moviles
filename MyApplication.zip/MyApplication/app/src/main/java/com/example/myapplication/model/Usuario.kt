package com.example.myapplication.model

data class Usuario(
    val nombre: String,
    val email: String,
    val password: String,
    val rol: String = "Chef" // Roles solicitados: chefs, emprendedores, prospectos
)