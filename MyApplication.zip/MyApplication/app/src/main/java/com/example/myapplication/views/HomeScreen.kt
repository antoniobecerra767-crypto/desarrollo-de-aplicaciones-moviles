package com.example.myapplication.views

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp

@Composable
fun HomeScreen(email: String?) {
    var buscador by remember { mutableStateOf("") }

    val context = LocalContext.current

    Column(
        modifier = Modifier.fillMaxSize().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text("Bienvenido, $email", style = MaterialTheme.typography.titleLarge)

        OutlinedTextField(
            value = buscador,
            onValueChange = { buscador = it },
            label = { Text("Buscar recetas o productos") },
            modifier = Modifier.fillMaxWidth()
        )

        Text("Talleres y Demostraciones", style = MaterialTheme.typography.titleMedium)

        Button(onClick = {
            val urlVideo = "https://www.youtube.com/watch?v=Dz20QKTeK5I"
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse(urlVideo))
            context.startActivity(intent)
        }) {
            Text("Ver Taller en YouTube")
        }
    }
}