package com.example.myapplication.viewmodel

import android.content.Context
import androidx.compose.runtime.State
import androidx.compose.runtime.mutableStateOf
import androidx.lifecycle.ViewModel

class AuthViewModel : ViewModel() {

    private val _nombre = mutableStateOf("")
    val nombre: State<String> = _nombre

    private val _rut = mutableStateOf("")
    val rut: State<String> = _rut

    private val _nombreError = mutableStateOf<String?>(null)
    val nombreError: State<String?> = _nombreError

    private val _rutError = mutableStateOf<String?>(null)
    val rutError: State<String?> = _rutError

    fun onNombreChange(nuevoNombre: String) {
        _nombre.value = nuevoNombre
        _nombreError.value = if (nuevoNombre.length < 3) "Mínimo 3 caracteres" else null
    }

    fun onRutChange(nuevoRut: String) {
        _rut.value = nuevoRut
        _rutError.value = if (!nuevoRut.contains("-")) "Debe contener guion" else null
    }

    fun validarFormularioCompleto(): Boolean {
        var isValid = true
        if (_nombre.value.isBlank()) {
            _nombreError.value = "Campo obligatorio"
            isValid = false
        }
        if (_rut.value.isBlank()) {
            _rutError.value = "Campo obligatorio"
            isValid = false
        }
        return isValid
    }

    fun guardarClienteLocal(context: Context) {
        val prefs = context.getSharedPreferences("master_martini_prefs", Context.MODE_PRIVATE)
        prefs.edit()
            .putString("ultimo_nombre_local", _nombre.value)
            .putString("ultimo_rut_empresa", _rut.value)
            .apply()
    }

    var errorVisual = mutableStateOf(false)
    var mensaje = mutableStateOf("")

    fun login(context: Context, email: String, contrasena: String): Boolean {
        if (email.isNotBlank() && contrasena.isNotBlank()) {
            val prefs = context.getSharedPreferences("master_martini_prefs", Context.MODE_PRIVATE)
            prefs.edit().putString("ultimo_email_login", email).apply()

            errorVisual.value = false
            mensaje.value = "Ingreso exitoso"
            return true
        } else {
            errorVisual.value = true
            mensaje.value = "Por favor, llene todos los campos"
            return false
        }
    }
}